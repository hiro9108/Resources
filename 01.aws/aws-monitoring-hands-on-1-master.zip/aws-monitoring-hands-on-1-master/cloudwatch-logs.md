# CloudWatch Logs

## 公式ドキュメント

CloudWatch Logs - ウィザードを使用して CloudWatch エージェント設定ファイルを作成する
https://docs.aws.amazon.com/ja_jp/AmazonCloudWatch/latest/monitoring/create-cloudwatch-agent-configuration-file-wizard.html