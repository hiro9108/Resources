# WordPressの設定について

## データベース

データベース名: wordpress
ユーザー名: dbmaster
パスワード: H&ppyHands0n
データベースのホスト名: RDSのエンドポイント
テーブル接頭辞: wp_

## サイトの設定

サイトのタイトル: Monitoring #1
ユーザー名: admin
パスワード: 出力された文字列をコピーしておいてください
メールアドレス: username@example.com (実際には送信されません)
検索エンジンでの表示: チェックを入れる